from transformers import AutoTokenizer, AutoModel
from sklearn.preprocessing import normalize
import pandas as pd
import torch
import chromadb
from chromadb.config import Settings

# Configuración de ChromaDB
client = chromadb.Client(Settings(
    chroma_db_impl="duckdb+parquet",
    persist_directory="chroma_db_storage"  # Cambia el directorio si es necesario
))

# Crear o conectar una colección en ChromaDB
collection_name = "product_embeddings"
collection = client.get_or_create_collection(name=collection_name)

# Modelo y tokenizador
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(MODEL_NAME)

# Cargar el dataset limpio
df = pd.read_csv("combined_processed_data.csv")  # Ajusta la ruta a tu archivo
print("Primeras filas del dataset:")
print(df.head())

# Generar embeddings
descriptions = df["name"]  # Cambia "name" si la columna tiene otro nombre
tokens = tokenizer(
    descriptions.tolist(),
    padding=True,
    truncation=True,
    max_length=128,
    return_tensors="pt"
)

with torch.no_grad():
    outputs = model(**tokens)

embeddings = torch.mean(outputs.last_hidden_state, dim=1).cpu().numpy()

# Normalizar los embeddings
embeddings_normalized = normalize(embeddings, axis=1)

# Agregar los embeddings normalizados al DataFrame
df["embeddings"] = embeddings_normalized.tolist()

# Preparar los datos para ChromaDB
documents = descriptions.tolist()  # Descripciones como documentos
metadata = df.drop(columns=["embeddings"]).to_dict(orient="records")  # El resto como metadatos
ids = [str(i) for i in df.index]  # IDs únicos para cada documento

# Insertar los datos en la colección de ChromaDB
collection.add(
    documents=documents,
    metadatas=metadata,
    ids=ids,
    embeddings=embeddings_normalized.tolist()
)

# Persistir los datos en ChromaDB
client.persist()

print(f"Embeddings generados y guardados en ChromaDB en la colección '{collection_name}'.")
