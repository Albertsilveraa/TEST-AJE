import chromadb
import openai
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, Dict, List

# Inicializar FastAPI
app = FastAPI()

# Clase principal del sistema de búsqueda
class VectorSearchSystem:
    def __init__(self, db_path="chroma_db", collection_name="Drinks-collection"):
        self.chroma_client = chromadb.PersistentClient(path=db_path)
        self.collection = self.chroma_client.get_or_create_collection(name=collection_name)
        openai.api_key = 'sk-xxxxxxxxxxxxxxxxxxxx'  # Reemplaza con tu clave real

    def generate_embedding(self, text):
        response = openai.Embedding.create(
            input=text,
            model="text-embedding-ada-002"
        )
        return response['data'][0]['embedding']

    def refine_query(self, query):
        """Refina la consulta utilizando GPT-4"""
        messages = [
            {
                "role": "system",
                "content": (
                    "Eres un asistente especializado en consultas de productos de bebidas. "
                    "Refina consultas para optimizar búsquedas semánticas y eliminar ambigüedades."
                )
            },
            {"role": "user", "content": f"Consulta original: \"{query}\"\n\nConsulta refinada:"}
        ]
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=messages,
            max_tokens=100,
            temperature=0.7
        )
        return response.choices[0].message['content'].strip()

    def add_product(self, product_id, name, sub_category, ratings):
        """Añadir un producto al catálogo"""
        metadata = {"id": product_id, "name": name, "sub_category": sub_category, "ratings": ratings}
        embedding = self.generate_embedding(name)
        self.collection.add(documents=[name], metadatas=[metadata], ids=[product_id])
        return metadata

    def delete_product(self, product_id):
        """Eliminar un producto del catálogo"""
        self.collection.delete(ids=[product_id])
        return {"message": f"Producto {product_id} eliminado."}

    def semantic_search(self, query, top_k=5):
        """Búsqueda semántica en el catálogo"""
        refined_query = self.refine_query(query)
        query_embedding = self.generate_embedding(refined_query)
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=['metadatas']
        )
        return results['metadatas'][0] if results['metadatas'] else []

# Inicializar el sistema
search_system = VectorSearchSystem()

# Modelos Pydantic
class Product(BaseModel):
    product_id: str
    name: str
    sub_category: str
    ratings: Optional[float] = Field(ge=0, le=5)

class SearchQuery(BaseModel):
    query: str
    top_k: Optional[int] = 5

class NaturalQuery(BaseModel):
    description: str

# Endpoints
@app.post("/add_product")
def add_product(product: Product):
    try:
        response = search_system.add_product(
            product_id=product.product_id,
            name=product.name,
            sub_category=product.sub_category,
            ratings=product.ratings
        )
        return {"message": "Producto añadido", "data": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/delete_product/{product_id}")
def delete_product(product_id: str):
    try:
        return search_system.delete_product(product_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/search")
def search(query: SearchQuery):
    try:
        results = search_system.semantic_search(query.query, query.top_k)
        if not results:
            return {"message": "No se encontraron productos similares."}
        return {"results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/natural_query")
def natural_query(query: NaturalQuery):
    """Endpoint específico para consultas en lenguaje natural"""
    try:
        refined_query = search_system.refine_query(query.description)
        return {"refined_query": refined_query}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
